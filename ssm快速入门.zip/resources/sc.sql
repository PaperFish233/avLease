/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 80017
Source Host           : localhost:3306
Source Database       : ssmlearn

Target Server Type    : MYSQL
Target Server Version : 80017
File Encoding         : 65001

Date: 2020-04-30 19:33:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `sc`
-- ----------------------------
DROP TABLE IF EXISTS `sc`;
CREATE TABLE `sc` (
  `Sno` char(9) NOT NULL,
  `Cno` char(10) NOT NULL,
  `Grade` decimal(4,1) DEFAULT NULL,
  PRIMARY KEY (`Cno`,`Sno`),
  KEY `Sno` (`Sno`),
  CONSTRAINT `sc_ibfk_1` FOREIGN KEY (`Cno`) REFERENCES `course` (`Cno`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sc_ibfk_2` FOREIGN KEY (`Sno`) REFERENCES `student` (`Sno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ck` CHECK (((`Grade` >= 0) and (`Grade` <= 100)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sc
-- ----------------------------
INSERT INTO `sc` VALUES ('202131401', '501202002', null);
INSERT INTO `sc` VALUES ('205151204', '712302021', '20.0');
INSERT INTO `sc` VALUES ('202131401', '809023501', '89.3');
INSERT INTO `sc` VALUES ('202131402', '809023501', '99.0');
INSERT INTO `sc` VALUES ('202131401', '809023506', '80.0');
INSERT INTO `sc` VALUES ('202131402', '809023506', '99.0');
INSERT INTO `sc` VALUES ('202131401', '809102001', '90.0');
INSERT INTO `sc` VALUES ('202131402', '809102001', '99.0');
INSERT INTO `sc` VALUES ('205151204', '809102001', '80.0');
DROP TRIGGER IF EXISTS `sc_update`;
DELIMITER ;;
CREATE TRIGGER `sc_update` AFTER UPDATE ON `sc` FOR EACH ROW begin
        insert into grade_log value (NEW.Sno,NEW.Cno,OLD.Grade,NEW.Grade,current_time());
    end
;;
DELIMITER ;
