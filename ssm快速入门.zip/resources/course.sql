/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 80017
Source Host           : localhost:3306
Source Database       : ssmlearn

Target Server Type    : MYSQL
Target Server Version : 80017
File Encoding         : 65001

Date: 2020-04-30 19:33:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `course`
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `Cno` char(9) NOT NULL,
  `Cname` char(40) NOT NULL,
  `Cpno` char(10) DEFAULT NULL,
  `Ccredit` decimal(3,1) DEFAULT '1.0',
  PRIMARY KEY (`Cno`),
  KEY `Cpno` (`Cpno`),
  CONSTRAINT `course_ibfk_1` FOREIGN KEY (`Cpno`) REFERENCES `course` (`Cno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('501202002', '《红楼梦》欣赏', null, '2.0');
INSERT INTO `course` VALUES ('712302021', '模拟电子技术', '809102001', '3.5');
INSERT INTO `course` VALUES ('809023501', '数据结构', '809102001', '4.0');
INSERT INTO `course` VALUES ('809023506', '数据库原理', '809023501', '4.0');
INSERT INTO `course` VALUES ('809102001', '大学计算机基础', null, '2.0');
