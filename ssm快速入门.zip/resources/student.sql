/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 80017
Source Host           : localhost:3306
Source Database       : ssmlearn

Target Server Type    : MYSQL
Target Server Version : 80017
File Encoding         : 65001

Date: 2020-04-30 19:33:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `Sno` char(9) NOT NULL,
  `Sname` char(20) NOT NULL,
  `Ssex` char(2) DEFAULT NULL,
  `Sage` smallint(6) DEFAULT '18',
  `Sdept` char(30) NOT NULL,
  PRIMARY KEY (`Sno`,`Sdept`),
  CONSTRAINT `student_chk_1` CHECK ((`Ssex` in (_utf8mb3'男',_utf8mb3'女')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('202131401', '李勇', '男', '20', '计算机');
INSERT INTO `student` VALUES ('202131402', '刘晨', '女', '19', '计算机');
INSERT INTO `student` VALUES ('202141102', '李平', '男', '18', '计算机');
INSERT INTO `student` VALUES ('205151204', '刘力', '男', '21', '电力');
