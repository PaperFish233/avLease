# SSM快速入门

## ssm简介&原理

ssm分别是

1. spring
2. spring mvc
3. mybatis

这三个框架分别解决三个web开发不同层级的问题

## mybatis

> **MyBatis 是一款优秀的持久层框架，它支持自定义 SQL、存储过程以及高级映射。MyBatis 免除了几乎所有的 JDBC 代码以及设置参数和获取结果集的工作。MyBatis 可以通过简单的 XML 或注解来配置和映射原始类型、接口和 Java POJO（Plain Old Java Objects，普通老式 Java 对象）为数据库中的记录。**

使用mybatis所需要知道的

1. 只需要给出dao层的接口，剩下的mybatis帮你做

2. sqlSessionFactory

    建造SqlSession

3. sqlSession

    提供实现好的Mapper

4. mapper.xml写在dao的同级目录下

## spring

Spring是一个分层的Java开源框架，以IoC（反转控制）和AOP（面向切面编程）为内核

#### spring的优势 

1.  方便解耦，简化开发
2. AOP编程的支持
3. 声明式事物的支持
4. 方便程序测试
5. 方便继承各种优秀框架
6. 降低Java EE API的使用难度

#### spring 7大模块

1. Spring Core
2. Spring AOP
3. Spring ORM
4. Spring DAO
5. Spring Web
6. Spring Context
7. Spring Web MVC

### IOC 理论推导

![container magic](https://docs.spring.io/spring-framework/docs/current/spring-framework-reference/images/container-magic.png)

#### 原来的步骤

1. UserDao 接口
2. UserDaoImpl 实现类
3. UserService 业务接口
4. UserServiceImpl 实现类

在原来的代码中，用户更改一个需求需要更改很多代码，如果代码量很大，代价很高。

如果使用`Set`接口注入，就可以实现灵活的更换实现方式
之前，程序上主动创建对象，控制权在程序员手上，使用Set注入，程序不再具有主动性，程序只负责被动接收对象。
程序员不用去管理去管理对象的创建了
控制反转了，主动权交给用户了，IOC的原型



### 依赖注入 DI

把有依赖关系的类放到容器中，解析出这些类的实例，就是依赖注入。目的是实现类的解耦

我不再去new，而是接收spring容器提供的对象

#### Spring 自动装配

自动装配是Spring满足bean依赖的一种方式		

Spring会在上下文中自动寻找并自动给bean装配属性		

在Spring中有3种装配的方式

1. 在xml种显式的配置
2. 在java种显式配置
3. **隐式的自动装配**

### AOP

AOP是面向切面编程，aop是基于动态代理的，这里简单介绍一下动态代理

#### 动态代理

1. 动态代理和静态代理角色一样
2. 动态代理的代理类是动态生成的，不是我们直接写好的
3. 动态代理分为两大类：基于接口的动态代理，基于类的动态代理
    - 基于接口：JDK的动态代理
    - 基于类：cglib

##### 动态代理的好处

1. 可以使真实角色更加纯粹
2. 公共事务交给代理角色
3. 公共业务扩展时可以集中管理
4. 一个动态代理类代理的是一个接口，一般对应一类业务
5. 一个动态代理类可以代理多个类，只要实现同一个接口

#### AOP的好处

1. 扩展方便
2. 不会影响原来的程序
3. 便于维护

 使用AOP的地方有很多，比如：添加日志，安全管理，事务管理

## spring mvc

spring mvc是一个视图层的框架

### mvc 简介

![JSP中的MVC模式](http://c.biancheng.net/uploads/allimg/190712/5-1ZG2093502940.gif)

### 核心对象

1. DispatcherServlet：前端控制器
2. HandlerMapping：处理器映射器
3. HandlerAdapter：处理器适配器
4. ViewResolver：视图解析器

### 什么是模型

Model（模型）：数据模型，提供要展示的数据，因此包含**数据**和**行为**，可以认为是领域模型或 JavaBean 组件（包含数据和行为），不过现在一般都分离开来：Value Object（数据） 和 服务层（行为）。也就是模型提供了模型数据查询和模型数据的状态更新等功能，包括数据和业务。

### 什么是视图

展示数据的组件，比如说jsp，html等

### 从请求到响应

![21.png](https://i.loli.net/2020/04/14/t4OMSdgAwT5IYyl.png)

!![image-20200430234555479](C:\Users\高境辰\AppData\Roaming\Typora\typora-user-images\image-20200430234555479.png)



## ssm整合原理

![img](https://images2015.cnblogs.com/blog/943689/201608/943689-20160802174152981-138115232.jpg)

底层由spring core来进行支持

层级架构清晰，spring core是核心



## 使用eclipse搭建ssm环境

### 安装Spring的插件（可选）

![image-20200430144101781](C:\Users\高境辰\AppData\Roaming\Typora\typora-user-images\image-20200430144101781.png)

![image-20200430144132599](C:\Users\高境辰\AppData\Roaming\Typora\typora-user-images\image-20200430144132599.png)

要添加插件的url如下

> http://dist.springsource.com/release/TOOLS/update/e4.10/

选中

1. Core/Spring IDE
2. Extensions/Spring IDE
3. Integrations/Spring IDE
4. Resources/Spring IDE

一路next/finish，等待安装完成，重启eclipse

然后进行漫长的等待

###  创建web项目

contextPath设置为`/`

#### 导入包的依赖

在`WEB-INF`目录下`lib`目录下添加所有的包

![image-20200430180514429](C:\Users\高境辰\AppData\Roaming\Typora\typora-user-images\image-20200430180514429.png)

添加到buildpath

#### 创建包

`src`目录下创建com.springLearn目录

创建基础的四个包

1. controller
2. service
3. pojo
4. dao

#### 配置的创建

src下新建`applicationContext.xml`，这是spring的主配置文件

约束如下

```xml
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context" 
       xmlns:tx="http://www.springframework.org/schema/tx"
       xmlns:mvc="http://www.springframework.org/schema/mvc"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd
        http://www.springframework.org/schema/context
        http://www.springframework.org/schema/context/spring-context.xsd 
        http://www.springframework.org/schema/mvc
        http://www.springframework.org/schema/mvc/spring-mvc.xsd
        http://www.springframework.org/schema/tx 
        http://www.springframework.org/schema/tx/spring-tx.xsd">
</beans>
```

再继续创建

1. `spring-dao.xml`
2. `spring-mvc.xml`
3. `spring-service.xml`

这样创建的好处是调理清晰，便于我们去管理，都把约束复制到里面去

最后创建mybatis的配置文件：`mybatis-config.xml`

添加mybatis 的约束

```xml
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">

<configuration>
   
</configuration>
```

### 进行文件配置

#### 配置mybatis的配置文件

mybatis和spring结合后，大部分的配置由spring接管，只需要配一小部分

配置如下

```xml
<typeAliases>
    <package name="com.springLearn.pojo"/>
</typeAliases>
<mappers>
    <package name="com.springLearn.dao"/>
</mappers>
```

- `mappers`是配置mappers类，也就是Dao类的位置，填写dao的全限定名
- `typeAliases`是取别名，在配置mapper.xml的时候就不用取填写全限定类名了

特别注意，这里的typeAliases和mappers不能颠倒，否则会报错

#### 配置spring-dao

spring-dao的配置主要分为以下两个方面

1. 配置mybatis的核心对象
2. 扫描dao包，注册为Bean

##### 配置mybatis

mybatis有两个核心的对象

1. sqlSessionFactory
2. sqlSession

在spring中，因为我们刚刚导入了包中有一个包叫`spring-mybatis`，这个包连接了spring和mybatis

所有我们的核心对象就变成了

1. sqlSessionFactory
2. sqlSessionTemplate

其中sqlSessionTemplate的作用和sqlSession差不多，只是spring对其做了一层封装

所以我们要配置的东西有

1. dataSource
2. sqlSessionFactory
3. sqlSessionTemplate

配置如下

这里我使用了druid连接池，当然也可以用其他连接池

这些<property>标签都是为`DruidDataSource`中的属性进行值的注入 

```xml
<!-- 数据库连接池 -->
<bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource">
    <property name="driverClassName" value="com.mysql.cj.jdbc.Driver"/>
    <property name="url" value="jdbc:mysql://localhost:3306/ssmlearn?serverTimezone=UTC"/>
    <property name="username" value="root"/>
    <property name="password" value="root"/>
    <property name="initialSize" value="5"/>
    <property name="maxActive" value="10"/>
    <property name="maxWait" value="3000"/>
</bean>

<!-- 配置SqlSessionFactory对象 -->
<bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
    <property name="dataSource" ref="dataSource" />
    <property name="configLocation" value="classpath:mybatis-config.xml"/>
</bean>

<!--在此不使用 MapperScannerConfigurer 官方文档已经指出：MapperScannerConfigurer 经常会产生错误-->
<!--官方文档 : http://mybatis.org/spring/zh/mappers.html -->
<!--sqlSessionTemplate 解释 ：http://mybatis.org/spring/zh/sqlsession.html-->
<bean id="sqlSessionTemplate" class="org.mybatis.spring.SqlSessionTemplate">
    <constructor-arg index="0" ref="sqlSessionFactory"/>
</bean>
```

##### 配置扫描dao

我们要把dao包下的所有有注解的类都作为组件注册到spring 容器中去

```xml
<content:component-scan base-package="com.springLearn.dao"/>
```

完整配置：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context" xmlns:tx="http://www.springframework.org/schema/tx"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd
        http://www.springframework.org/schema/context
        http://www.springframework.org/schema/context/spring-context.xsd 
        http://www.springframework.org/schema/tx 
        http://www.springframework.org/schema/tx/spring-tx.xsd">
        <bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource">
        	<property name="driverClassName" value="com.mysql.cj.jdbc.Driver"/>
		    <property name="url" value="jdbc:mysql://localhost:3306/ssmlearn?serverTimezone=UTC"/>
		    <property name="username" value="root"/>
		    <property name="password" value="root"/>
		    <property name="initialSize" value="5"/>
		    <property name="maxActive" value="10"/>
		    <property name="maxWait" value="3000"/>
        </bean>
        <bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
     		<property name="dataSource" ref="dataSource"></property>
     		<property name="configLocation" value="classpath:mybatis-config.xml"></property>
        </bean>
        <bean id="sqlSession" class="org.mybatis.spring.SqlSessionTemplate">
        	<constructor-arg index="0" ref="sqlSessionFactory"></constructor-arg>
        </bean>
        <context:component-scan base-package="com.springLearn.dao"></context:component-scan>
       
</beans>
```



#### 配置spring-service

service层的主要目的是配置组件的注册

和刚刚的dao层一样

```xml
<context:component-scan base-package="com.springLearn.service" />
```

全部配置:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context" 
       xmlns:tx="http://www.springframework.org/schema/tx"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
       http://www.springframework.org/schema/beans/spring-beans.xsd
       http://www.springframework.org/schema/context
       http://www.springframework.org/schema/context/spring-context.xsd
       http://www.springframework.org/schema/tx
       http://www.springframework.org/schema/tx/spring-tx.xsd">

    <!-- 扫描service相关的bean -->
    <context:component-scan base-package="com.springLearn.service"/>

</beans>
```

#### 配置spring-mvc

spring-mvc需要配置的内容主要有几个

1. 配置注解驱动
2. 静态资源过滤
3. 视图解析器
4. 扫描service包

```xml
<!-- 1.开启SpringMVC注解驱动 -->
<mvc:annotation-driven/>

<!-- 2.静态资源默认servlet配置-->
<mvc:default-servlet-handler/>

<!-- 3.配置jsp 显示ViewResolver视图解析器 -->
<bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
    <property name="viewClass" value="org.springframework.web.servlet.view.JstlView" />
    <property name="prefix" value="/WEB-INF/jsp/" />
    <property name="suffix" value=".jsp" />
</bean>

<context:component-scan base-package="com.springLearn.controller"/>
```

原本需要配置的处理器和适配器只需要配置`<mvc:annotation-driven/>`注解和`<mvc:default-servlet-handler/>`就可以了

1. viewClass视图类型
2. prefix前缀
3. suffix后缀

全部配置如下

```xml
<?xml version="1.0" encoding="UTF-8"?>

<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:mvc="http://www.springframework.org/schema/mvc"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
       http://www.springframework.org/schema/beans/spring-beans.xsd
       http://www.springframework.org/schema/mvc
       http://www.springframework.org/schema/mvc/spring-mvc.xsd
       http://www.springframework.org/schema/context
       http://www.springframework.org/schema/context/spring-context.xsd">
        
		<!-- 1.开启SpringMVC注解驱动 -->
		<mvc:annotation-driven/>
		
		<!-- 2.静态资源默认servlet配置-->
		<mvc:default-servlet-handler/>
		
		<!-- 3.配置jsp 显示ViewResolver视图解析器 -->
		<bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
		    <property name="viewClass" value="org.springframework.web.servlet.view.JstlView" />
		    <property name="prefix" value="/WEB-INF/jsp/" />
		    <property name="suffix" value=".jsp" />
		</bean>
		
		<context:component-scan base-package="com.springLearn.controller"></context:component-scan>
        
</beans>
```



#### 配置application-context

把刚刚的三个配置导入即可

```xml
<import resource="spring-dao.xml"/>
<import resource="spring-service.xml"/>
<import resource="spring-mvc.xml"/>
```

完整配置：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context" xmlns:tx="http://www.springframework.org/schema/tx"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd
        http://www.springframework.org/schema/context
        http://www.springframework.org/schema/context/spring-context.xsd 
        http://www.springframework.org/schema/tx 
        http://www.springframework.org/schema/tx/spring-tx.xsd">
        
        <import resource="classpath:spring-dao.xml"/>
        <import resource="classpath:spring-service.xml"/>
        <import resource="classpath:spring-mvc.xl"/>
</beans>
```

## 编写代码

至此，配置的部分就结束了，我们可以先试一下能不能进行运行

我们使用的数据库有三张表，是一个比较简单的数据库

```sql
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `Cno` char(9) NOT NULL,
  `Cname` char(40) NOT NULL,
  `Cpno` char(10) DEFAULT NULL,
  `Ccredit` decimal(3,1) DEFAULT '1.0',
  PRIMARY KEY (`Cno`),
  KEY `Cpno` (`Cpno`),
  CONSTRAINT `course_ibfk_1` FOREIGN KEY (`Cpno`) REFERENCES `course` (`Cno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('501202002', '《红楼梦》欣赏', null, '2.0');
INSERT INTO `course` VALUES ('712302021', '模拟电子技术', '809102001', '3.5');
INSERT INTO `course` VALUES ('809023501', '数据结构', '809102001', '4.0');
INSERT INTO `course` VALUES ('809023506', '数据库原理', '809023501', '4.0');
INSERT INTO `course` VALUES ('809102001', '大学计算机基础', null, '2.0');
```

```sql
DROP TABLE IF EXISTS `sc`;
CREATE TABLE `sc` (
  `Sno` char(9) NOT NULL,
  `Cno` char(10) NOT NULL,
  `Grade` decimal(4,1) DEFAULT NULL,
  PRIMARY KEY (`Cno`,`Sno`),
  KEY `Sno` (`Sno`),
  CONSTRAINT `sc_ibfk_1` FOREIGN KEY (`Cno`) REFERENCES `course` (`Cno`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sc_ibfk_2` FOREIGN KEY (`Sno`) REFERENCES `student` (`Sno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ck` CHECK (((`Grade` >= 0) and (`Grade` <= 100)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sc
-- ----------------------------
INSERT INTO `sc` VALUES ('202131401', '501202002', null);
INSERT INTO `sc` VALUES ('205151204', '712302021', '20.0');
INSERT INTO `sc` VALUES ('202131401', '809023501', '89.3');
INSERT INTO `sc` VALUES ('202131402', '809023501', '99.0');
INSERT INTO `sc` VALUES ('202131401', '809023506', '80.0');
INSERT INTO `sc` VALUES ('202131402', '809023506', '99.0');
INSERT INTO `sc` VALUES ('202131401', '809102001', '90.0');
INSERT INTO `sc` VALUES ('202131402', '809102001', '99.0');
INSERT INTO `sc` VALUES ('205151204', '809102001', '80.0');
DROP TRIGGER IF EXISTS `sc_update`;
```

```sql
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `Sno` char(9) NOT NULL,
  `Sname` char(20) NOT NULL,
  `Ssex` char(2) DEFAULT NULL,
  `Sage` smallint(6) DEFAULT '18',
  `Sdept` char(30) NOT NULL,
  PRIMARY KEY (`Sno`,`Sdept`),
  CONSTRAINT `student_chk_1` CHECK ((`Ssex` in (_utf8mb3'男',_utf8mb3'女')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('202131401', '李勇', '男', '20', '计算机');
INSERT INTO `student` VALUES ('202131402', '刘晨', '女', '19', '计算机');
INSERT INTO `student` VALUES ('202141102', '李平', '男', '18', '计算机');
INSERT INTO `student` VALUES ('205151204', '刘力', '男', '21', '电力');
```

### 编写实体类

```java
public class Student {
	private String no;
	private String name;
	private String sex;
	private int age;
	private String dept;
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
}
```

```java
public class Course {
	private String no;
	private String name;
	private String cpno;
	private double credit;
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCpno() {
		return cpno;
	}
	public void setCpno(String cpno) {
		this.cpno = cpno;
	}
	public double getCredit() {
		return credit;
	}
	public void setCredit(double credit) {
		this.credit = credit;
	}
	
}

```

### 编写第一个Dao

在dao包下创建一个接口`StudentMapper`，里面定义了一个方法

```java
public interface StudentMapper {
	public List<Student> findAllStudent(); 
}
```

很简单的接口，接口中只有一个方法

#### 编写mybatis

mybatis中每一个接口都需要有一个mapper.xml对应，所以，在`resource`下建立包

在xml文件中添加以下约束

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="">
</mapper>
```

开始编写sql

首先我们需要编写的是数据库表到实体类的结果集映射

```xml
<resultMap type="student" id="studentMap">
    <id property="no" column="Sno"/>
    <result property="name" column="Sname"/>
    <result property="sex" column="Ssex"/>
    <result property="age" column="Sage"/>
    <result property="dept" column="Sdept"/>
</resultMap>
```

1. type：是这个返回的实体类的名字，因为我们已经配置了别名，所以这里不用写全限定类名

2. id：这是这个map的名字

3. id标签：标明主键

4. result：其他部分

5. property：对应实体类的属性名

6. column：对应表的属性名

编写查询语句

```xml
<select id="findAllStudent" resultMap="studentMap">
    select * from student
</select>
```

1. id：是对应接口的方法名
2. resultMap：结果集映射

#### 编写Dao的实现类

因为，我们不能每次都获取sqlSession取出实现类，我们直接把实现类进行封装，存到容器中

在dao下建立impl包，存放实现类，新建`StudentDao`

```java
@Repository
public class StudentDao implements StudentMapper{

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public List<Student> findAllStudent() {
		// TODO Auto-generated method stub
		return sqlSession.getMapper(StudentMapper.class).findAllStudent();
	}

}
```

1. 首先给这个类注册到spring容器
2. 注入sqlSessionTemplate
3. 编写实现的方法

### 编写Service

在Service包下创建接口`StudentService`

```java
public interface StudentService {
	public List<Student> findAllStudent();
	
}
```

同级目录创建impl包，新建`StudentServiceImpl`

```java
@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentDao studentDao;
	
	@Override
	public List<Student> findAllStudent() {
		// TODO Auto-generated method stub
		return studentDao.findAllStudent();
	}

}
```

1. 注册到spring容器
2. 注入StudentDao
3. 实现方法

### 编写Controller

在controller包下编写

```java
@Controller
public class UserController {
	
	@Autowired
	private StudentServiceImpl studentService;
	
	@RequestMapping("/allStudent")
	public String showAllStudent(Model model)
	{
		List<Student> students = studentService.findAllStudent();
		model.addAttribute("students",students);
		return "allStudent";
	}
}
```

1. 作为Controller注册
2. 注入StudentService
3. 编写方法，添加@RequestMapping指名访问路径
4. 使用Model进行传参（存在request对象中）
5. 返回视图名，交给视图解析器处理

### 编写前端页面

我们刚刚的视图解析器中配置了视图的路径

在`WEB-INF/jsp`目录下

要建在这个目录下的最大的原因是保证视图的安全，保证直接访问访问不到我们的视图，只能通过Controller进行跳转

我们创建`allStudent.jsp`

```jsp
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>所有学生</title>
</head>
<body>
	
	<table>
		<tr>
			<th>编号</th>
			<th>姓名</th>
			<th>年龄</th>
			<th>性别</th>
		</tr>
		<c:forEach varStatus="s" var="student" items="${students}">
			<tr>
				<td>${student.no}</td>
				<td>${student.name}</td>
				<td>${student.age}</td>
				<td>${student.sex}</td>
			</tr>
		</c:forEach>
		
	</table>
</body>
</html>
```

### 配置web.xml

还记得Spring mvc的最重要的东西吗，`DispathcerServlet`，我们需要把它当成一个普通的Servlet在web.xml中配置它

```xml
<servlet>
    <servlet-name>DispatcherServlet</servlet-name>
    <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
    <init-param>
         <param-name>contextConfigLocation</param-name>
         <!--一定要注意:我们这里加载的是总的配置文件，之前被这里坑了！-->
         <param-value>classpath:applicationContext.xml</param-value>
    </init-param>
    <load-on-startup>1</load-on-startup>
</servlet>
<servlet-mapping>
    <servlet-name>DispatcherServlet</servlet-name>
    <!--注意这里不能配置成/*-->
    <url-pattern>/</url-pattern>
</servlet-mapping>

<!--encodingFilter-->
<filter>
    <filter-name>encodingFilter</filter-name>
    <filter-class>
        org.springframework.web.filter.CharacterEncodingFilter
    </filter-class>
    <init-param>
        <param-name>encoding</param-name>
        <param-value>utf-8</param-value>
    </init-param>
</filter>
<filter-mapping>
    <filter-name>encodingFilter</filter-name>
    <url-pattern>/*</url-pattern>
</filter-mapping>
```

此外，为了解决编码问题，我们还可以配置一个过滤器帮助我们解决编码问题

### 获取一些参数

Spring MVC获取参数的方式

通过@RequestParam获取参数

#### 设计表单

设计一个表单，提交表单提交数据给controller

```jsp
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>查找学生</title>
</head>
<body>
	<form action="${pageContext.request.contextPath}/findStudentById" method="post">
		学号:<input type="text" name="id"><br/>
		<input type="submit">
	</form>
</body>
</html>
```

#### 设计路由Controller

设计一个路由器controller访问这个jsp页面

因为视图安全，不能直接访问这个jsp页面，所以我们需要通过一个controller

```java
@Controller
public class RouteController {
	
	@RequestMapping("/route/{url}")
	public String route(@PathVariable String url)
	{
		return url;
	}
}
```

这里介绍一个全新的传参方式-----restful风格传参

把参数放在url中，进一步保证了安全性

#### 设计dao

再设计一个dao的方法，和刚刚一样

```java
public Student findStudentById(@Param("no") String id);
```

`@Param`注解是指明参数的，只有一个参数的情况下不加也没事，好习惯，加上

#### 设计mapper.xml

设计xml

```xml
<select id="findStudentById" resultMap="studentMap">
    select * from student where Sno=#{no}
</select>
```

mybatis中的参数传递非常方便，直接使用`#{}`进行传递

再写一下StudentDao

```java
@Override
public Student findStudentById(String id) {
    // TODO Auto-generated method stub
    return sqlSession.getMapper(StudentMapper.class).findStudentById(id);
}
```

#### 设计service

编写一下Service层

```java
public Student findStudentById(String id);
```

```java
@Override
public Student findStudentById(String id) {
    // TODO Auto-generated method stub
    return studentDao.findStudentById(id);
}
```

#### 设计controller

最后，编写Controller

```java
@RequestMapping("/findStudentById")
public String findStudentById(@RequestParam("id") String id,Model model)
{
    Student student = studentService.findStudentById(id);
    List<Student> students = new ArrayList<Student>();
    students.add(student);
    model.addAttribute("students",students);
    return "allStudent";
}
```

1. 这个@RequestParam的`value `和前端页面的表单的`name`相对应
2. 这里为了复用视图，我把单个查询结果进行了封装








​    

​    







