package com.springLearn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springLearn.dao.StudentMapper;
import com.springLearn.pojo.Student;
import com.springLearn.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentMapper studentDao;
	
	
	@Override
	public List<Student> findAllStudents() {
		// TODO Auto-generated method stub
		return studentDao.findAllStudents();
	}


	@Override
	public Student findStudentById(String id) {
		// TODO Auto-generated method stub
		return studentDao.findStudentById(id);
	}

}
