package com.springLearn.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springLearn.pojo.Student;
import com.springLearn.service.StudentService;

@Controller
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@RequestMapping(value="/allStudents")
	public String allStudents(Model model)
	{
		//����service�㷵��list
		List<Student> students = studentService.findAllStudents();
		//��ģ������������
		model.addAttribute("students",students);
		//������ͼ����������ͼ����������
		return "allStudent";
	}
	
	@RequestMapping("/findStudentById")
	public String findStudentById(Model model,@RequestParam("id")String id)
	{
		Student student = studentService.findStudentById(id);
		List<Student> list = new ArrayList<Student>();
		list.add(student);
		model.addAttribute("students",list);
		return "allStudent";
	}
}
