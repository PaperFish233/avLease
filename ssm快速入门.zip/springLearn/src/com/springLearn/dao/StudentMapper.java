package com.springLearn.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.springLearn.pojo.Student;


public interface StudentMapper {
	public List<Student> findAllStudents();
	public Student findStudentById(@Param("id")String id);
}
