package com.springLearn.dao.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springLearn.dao.StudentMapper;
import com.springLearn.pojo.Student;

@Repository
public class StudentDao implements StudentMapper{

	private SqlSessionTemplate sqlSession;
	
	@Autowired
	public void setSqlSession(SqlSessionTemplate sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	
	@Override
	public List<Student> findAllStudents() {
		// TODO Auto-generated method stub
		return sqlSession.getMapper(StudentMapper.class).findAllStudents();
	}


	@Override
	public Student findStudentById(String id) {
		// TODO Auto-generated method stub
		return sqlSession.getMapper(StudentMapper.class).findStudentById(id);
	}


}
